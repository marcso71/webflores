# MAR Flower Shop — Textos del catálogo

Tagline: Ramos de crochet hechos a mano que no se marchitan — flores para regalar hoy y guardar para siempre.
Contacto: TikTok @m.a.rflowerstudio

---

**01 — Ramo Clásico en Tonos Rosas y Crema**
Foto: 01-ramo-clasico-rosas-crema.jpg
Ramo voluminoso en tonos rosas y crema con envoltura translúcida.
Precio: S/ 350

**02 — Ramo en Caja Decorativa**
Foto: 02-ramo-caja-decorativa.jpg
Arreglo dentro de una caja con margaritas, tulipanes y flores texturizadas.
Precio: S/ 350

**03 — Ramo Multicolor Pastel**
Foto: 03-ramo-multicolor-pastel.jpg
Ramo variado en tonos rosa, blanco y azul con moño a juego.
Precio: S/ 250

**04 — Bouquet Denso Rosado**
Foto: 04-bouquet-denso-rosado.jpg
Bouquet denso visto desde arriba con flores en múltiples tonos de rosa.
Precio: S/ 45

**05 — Ramo Tonos Morados y Lilas**
Foto: 05-ramo-tonos-morados-lilas.jpg
Gran ramo en tonos morados y lilas sostenido frente a una cortina.
Precio: S/ 55

**06 — Ramo de Girasoles Clásico**
Foto: 06-ramo-girasoles-clasico.jpg
Ramo de girasoles tejidos adornado con mariposas doradas.
Precio: S/ 50

**07 — Ramo Lirios y Tulipanes**
Foto: 07-ramo-lirios-tulipanes.jpg
Elegante arreglo de lirios y tulipanes rosados con un lazo blanco.
Precio: S/ 50

**08 — Ramo Iluminado con LED**
Foto: 08-ramo-iluminado-led.jpg
Bouquet iluminado con luces LED rodeado de flores rosadas y capullos oscuros.
Precio: S/ 50

**09 — Ramo La.Bloomies**
Foto: 09-ramo-la-bloomies.jpg
Ramo de dos girasoles y lirios blancos con envoltura translúcida.
Precio: S/ 30

**10 — Bouquet Margaritas Azules**
Foto: 10-bouquet-margaritas-azules.jpg
Bouquet denso de margaritas en tonos azules y blancos con centros amarillos.
Precio: S/ 40

**11 — Canasta de Mimbre Floral**
Foto: 11-canasta-mimbre-floral.jpg
Arreglo floral de tulipanes y lirios rosados dentro de una canasta de mimbre.
Precio: S/ 30
